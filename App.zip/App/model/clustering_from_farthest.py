import pandas as pd
import numpy as np
import math

data = pd.read_csv("C:\Shreya\\NeenOpal\Exploring azure ml\data3.csv")

latitudes = data.iloc[:,1]
longitudes = data.iloc[:,2]
ids = data.iloc[:,0]
weights = data.iloc[:,3]
data.columns=["ID","Lat","Long","Weights"]
s = time.sum()
avg = s/30
avg = int(avg)
n = len(latitudes)

if num == "NULL":
    lat = latitudes.mean()
    lon = longitudes.mean()

else:
    lat = latitude
    lon = longitude


distr_dis=list() 

for i in range(n):
    dis = (((lat-latitudes[i])**2) + ((lon-longitudes[i])**2))**(1/2)
    distr_dis.append(dis)

distr_dis = pd.DataFrame(distr_dis)
distr_dis["ID"]=ids
distr_dis.columns = ["dis","ID"]
distr_dis = distr_dis.sort_values("dis",ascending=False)

count = 1
cluster_no = 1
flag1 = 1
flag2 = 1
while(cluster_no<=30):
    print(cluster_no)
    temp = distr_dis.iloc[0,:]
    data2 = data[data["ID"]==temp["ID"]]
    lat = data2["Lat"]
    long = data2["Long"]
    distances = pd.DataFrame()
    total_time = 0
    for i in range(len(data)):
        dis = (((lat-data.iloc[i,1])**2) + ((long-data.iloc[i,2])**2))**(1/2)
        y = {"dis":dis,
             "ID":data.iloc[i,0]}
        y = pd.DataFrame(y)
        distances=distances.append(y)
#        distances.append(dis)
#    rem_id = data.iloc[:,0]
#    length = len(rem_id)
#    distances = pd.DataFrame(distances,index=np.arange(length))
#    rem_id = pd.DataFrame(rem_id,index=np.arange(length))
#    #distances["Ret_Id"]=rem_id
#    distance=pd.concat([distances, rem_id], axis=1,ignore_index=True)
#    distance.columns = ["dis","Ret_Id"]
    distances = distances.sort_values("dis")
    num = 0
    for j in range(0,len(data)):
        count+=1
        num+=1
        row = data[data["ID"]==distances.iloc[j,1]]
        total_time += row.iloc[0,3]
        x = {"ID":row.iloc[0,0],
             "Latitude":row.iloc[0,1],
             "Longitude":row.iloc[0,2],
             "Weights":row.iloc[0,3],
             "Cluster_number":cluster_no}
        x = pd.DataFrame(x,index=[0])   
        if flag1==1:
            output1 = x
            flag1 = 0 
        else:
            #output1 = pd.concat([output1, x], ignore_index=True)
            output1 = output1.append(x)
        if(total_time >=avg and cluster_no!=30):
            break
    
        if(count==n):
            break

    if flag2==1:
        output2 = output1
        flag2=0
    else:
        #output2 = pd.concat([output1, x], ignore_index=True)
        output2 = output2.append(output1)
    for k in range(0,len(output1)):
        distr_dis=distr_dis[distr_dis["ID"] != output1.iloc[k,0]]
        data = data[data["ID"] != output1.iloc[k,0]]
    c = 0
    for l in range(len(distances)):
        if math.isnan(distances.iloc[l,1]):
            c+=1
            
    flag1=1    
    cluster_no+=1
    
            
output2.to_csv("C:\Shreya\\NeenOpal\Exploring azure ml\\farthest_dist_python.csv")

