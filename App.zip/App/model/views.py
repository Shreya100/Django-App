import keras
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from django.core.files.storage import FileSystemStorage
import pandas as pd
import numpy as np
import math
from django.core.files.storage import default_storage
import os
import csv
import re
from sklearn import preprocessing
def index(request):
	return render(request,'index.html',{})


def send(request):
	try:
		if request.method == 'POST' and request.FILES['myfile']:
			myfile = request.FILES['myfile']
			# no_cluster = int(request.POST.get('number'))
			# lat_long = request.POST.get("location")
			predict(myfile)
			return HttpResponse("<a href='/media/output.csv'>Click here</a>")
	except:
		return HttpResponse('Error:500')


def predict(file):
    test=file.read().decode("utf-8")
    dataset=pd.read_csv("trainms.csv")
    dataset = dataset.iloc[:,2:]
    test=test.iloc[:,2:]
    print(dataset)
    # dataset=dataset.drop(columns=['comments'],axis=1)
    print(dataset)
    test=test.drop(columns='comments',axis=1)
    for column in dataset.columns:
        dataset[column].fillna(dataset[column].mode()[0], inplace=True)

    for column in test.columns:
        test[column].fillna(test[column].mode()[0], inplace=True)


    for x in dataset.columns:
        if dataset[x].dtype == 'object':
            lbl = preprocessing.LabelEncoder()
            lbl.fit(list(dataset[x].values))
            dataset[x] = lbl.transform(list(dataset[x].values))

    for x in test.columns:
        if test[x].dtype == 'object':
            lbl = preprocessing.LabelEncoder()
            lbl.fit(list(test[x].values))
            test[x] = lbl.transform(list(test[x].values))

    y=dataset.loc[:,'treatment']
    x=dataset.drop(axis=1,columns=['treatment'])
    xc=x.iloc[:,:]
    cols=xc.columns
    x=pd.get_dummies(x,columns=cols)
    test=pd.get_dummies(test,columns=cols)

    for cols in x.columns:
        if cols not in test.columns:
            x=x.drop(axis=1,columns=cols)


    model=xg(n_estimators=100,learning_rate=0.01,max_depth=4,min_child_weight=1,subsample=0.1)
    model.fit(x,y)
    result=model.predict(test)
   

    flag =1

    for i in range(len(result)):
        x = pd.DataFrame({"s.no":(i+1),"treatment":result[i]},index=[0])
        if flag==1:
            ans = x
        else:
            ans = ans.append(x)

    
    ans.to_csv("media/output.csv",index=False)
    

    # df = pd.read_csv("media/output.csv")
    # json = df.to_json(orient="records")
    # print(json)


            
